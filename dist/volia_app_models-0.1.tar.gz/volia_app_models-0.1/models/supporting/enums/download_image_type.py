from enum import Enum


class DownloadImageType(str, Enum):
    BLACK = "BLACK"
    WHITE = "WHITE"
