from models.supporting.phrase_to_view import PhraseToView


class OutPhraseDetails(PhraseToView):
    pass
