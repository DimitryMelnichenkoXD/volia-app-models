from pydantic import BaseModel


class OutUserApply(BaseModel):
    pass
