from pydantic import BaseModel


class InPhraseDetails(BaseModel):
    uuid_phrase: str
